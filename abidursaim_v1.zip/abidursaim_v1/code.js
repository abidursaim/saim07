const sections = document.querySelectorAll("section");
const list = document.querySelectorAll(".navBar ul li");

window.addEventListener("scroll", ()=>{
    let watching = "";
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if(pageYOffset >= (sectionTop - sectionHeight / 4))
        {
            watching = section.getAttribute("id");
        }
    })

    list.forEach(li => {
        li.classList.remove("active");
        if(li.classList.contains(watching))
        {
            li.classList.add("active");
        }
    })
});

const textarea = document.querySelector(".contact .contact-all .form .inputBx textarea");
textarea.addEventListener("keyup", e =>{
    textarea.style.height = "40px";
    let scHeight = e.target.scrollHeight;
    textarea.style.height = `${scHeight}px`;
});

const ahover = document.querySelectorAll(".navBar-media ul li a");
function activeLink(){
    ahover.forEach((item) =>
    item.classList.remove('active'));
    this.classList.add('active')
}
ahover.forEach((item) =>
item.addEventListener('click',activeLink));

const menu = document.querySelector(".menu");
const navMedia = document.querySelector(".navBar-media");
menu.onclick = () =>{
    menu.classList.toggle("close");
    navMedia.classList.toggle("active");
}
function toggleMenu(){
    const menu = document.querySelector(".menu");
    const navMedia = document.querySelector(".navBar-media");
    menu.classList.toggle("close");
    navMedia.classList.toggle("active");
}